# TechVibe Invoice Android App

මෙය Android APK එකක් ලෙස build කිරීමට සකස් කළ source project එකයි.

## App එකේ පහසුකම්
- Original TechVibe logo එක app එක තුළම ඇතුළත් (offline).
- Customer සහ invoice details edit කිරීම.
- Service items එකතු කිරීම/ඉවත් කිරීම.
- Total Amount ස්වයංක්‍රීයව ගණනය කිරීම (Advance/Balance පේළි නැත).
- Invoice එක phone එකේ save කර History එකෙන් නැවත විවෘත කිරීම.
- Android Print dialog හරහා A4 PDF ලෙස Save කිරීම.
- Internet නොමැතිව භාවිතා කිරීම.

## APK build කිරීම
Android Studio සහ Android SDK 35 සහිත පරිගණකයක:
1. මෙම folder එක Android Studio තුළ Open කරන්න.
2. Gradle sync සම්පූර්ණ කරන්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. APK එක `app/build/outputs/apk/debug/app-debug.apk` තුළ ලැබේ.

GitHub Actions හරහා build කිරීමට workflow එක `.github/workflows/build-techvibe-invoice-apk.yml` තුළ සපයා ඇත. Project එක repository එකකට දමා workflow run කළ හැක.
